document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for your message!');
    this.reset();
  });
  
  const cart = {};

function addToCart(item, price) {
  if (!cart[item]) {
    cart[item] = { quantity: 1, price: price };
  } else {
    cart[item].quantity += 1;
  }
  updateCartUI();
}

function removeFromCart(item) {
  if (cart[item]) {
    cart[item].quantity -= 1;
    if (cart[item].quantity <= 0) {
      delete cart[item];
    }
  }
  updateCartUI();
}

function updateCartUI() {
  const cartItemsContainer = document.getElementById("cartItems");
  const subtotalEl = document.getElementById("subtotal");

  cartItemsContainer.innerHTML = "";
  let subtotal = 0;

  for (const item in cart) {
    const quantity = cart[item].quantity;
    const price = cart[item].price;
    const total = quantity * price;
    subtotal += total;

    const itemEl = document.createElement("div");
    itemEl.classList.add("cart-item");
    itemEl.innerHTML = `
      <span>${item} x ${quantity}</span>
      <span>$${total}</span>
    `;
    cartItemsContainer.appendChild(itemEl);
  }

  subtotalEl.textContent = subtotal.toFixed(2);
}

function placeOrder() {
    if (Object.keys(cart).length === 0) {
      alert("Your cart is empty. Please add items before placing an order.");
      return;
    }
  
    // You can expand this with actual checkout integration
    document.getElementById("order-status").textContent = "🎉 Order Confirmed! Thank you for your purchase.";
  
    // Optionally clear the cart
    for (const item in cart) {
      delete cart[item];
    }
    updateCartUI();
  }
  